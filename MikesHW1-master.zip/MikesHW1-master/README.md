# HW1

Modify the 'intro.sh' file to be about you
