#!/bin/bash

echo "Hello, let me introduce myself"

NAME=Mike
HOMETOWN=Kennewick
MAJOR=CS
FAVORITE_HOBBY=game

echo "My name is $NAME. I am originally from $HOMETOWN. My major is $MAJOR and in my free time I like to $FAVORITE_HOBBY"
